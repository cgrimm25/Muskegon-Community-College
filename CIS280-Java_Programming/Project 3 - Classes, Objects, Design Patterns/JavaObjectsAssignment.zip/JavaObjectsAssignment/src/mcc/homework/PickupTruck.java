package mcc.homework;

class PickupTruck extends Truck {
	public PickupTruck(String _make, String _model, int _year) {
		super(_make, _model, _year);
	}

	// @Overloading
	public PickupTruck(String _make, String _model, int _year, int _vin) {
		super(_make, _model, _year, _vin);
	}

}