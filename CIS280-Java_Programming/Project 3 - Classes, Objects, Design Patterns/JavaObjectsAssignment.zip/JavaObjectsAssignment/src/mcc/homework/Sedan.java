package mcc.homework;

class Sedan extends Car {
	public Sedan(String _make, String _model, int _year) {
		super(_make, _model, _year);
	}

	// @Overloading
	public Sedan(String _make, String _model, int _year, int _vin) {
		super(_make, _model, _year, _vin);
	}
}