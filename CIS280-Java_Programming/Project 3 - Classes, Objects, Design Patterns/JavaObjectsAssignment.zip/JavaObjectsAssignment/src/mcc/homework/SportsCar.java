package mcc.homework;

class SportsCar extends Car {
	public SportsCar(String _make, String _model, int _year) {
		super(_make, _model, _year);
	}

	// @Overloading
	public SportsCar(String _make, String _model, int _year, int _vin) {
		super(_make, _model, _year, _vin);
	}
}