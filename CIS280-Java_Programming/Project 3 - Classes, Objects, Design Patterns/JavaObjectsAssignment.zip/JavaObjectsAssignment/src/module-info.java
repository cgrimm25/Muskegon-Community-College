module JavaObjectsAssignment {
}