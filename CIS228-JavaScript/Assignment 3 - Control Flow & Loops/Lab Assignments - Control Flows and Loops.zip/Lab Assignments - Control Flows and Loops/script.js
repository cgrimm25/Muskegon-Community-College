function runIfElse() {
  const output = document.getElementById('if-else-output');
  let text = '';
  const num = 7;
  if (num > 0) {
    text = 'The number ' + num + ' is positive.';
  } else if (num < 0) {
    text = 'The number ' + num + ' is negative.';
  } else {
    text = 'The number is zero.';
  }
  output.innerText = text;
}

function runSwitch() {
  const output = document.getElementById('switch-output');
  let text = '';
  const day = 3;
  switch (day) {
    case 0:
      text = 'Sunday';
      break;
    case 1:
      text = 'Monday';
      break;
    case 2:
      text = 'Tuesday';
      break;
    case 3:
      text = 'Wednesday';
      break;
    case 4:
      text = 'Thursday';
      break;
    case 5:
      text = 'Friday';
      break;
    case 6:
      text = 'Saturday';
      break;
    default:
      text = 'Invalid day';
  }
  output.innerText = text;
}

function runForLoop() {
  const output = document.getElementById('for-loop-output');
  let text = '';
  for (let i = 1; i <= 5; i++) {
    text += 'Iteration ' + i + '<br>';
  }
  output.innerHTML = text;
}

function runWhileLoop() {
  const output = document.getElementById('while-loop-output');
  let text = '';
  let count = 5;
  while (count > 0) {
    text += 'Count: ' + count + '<br>';
    count--;
  }
  output.innerHTML = text;
}

function runDoWhileLoop() {
  const output = document.getElementById('do-while-loop-output');
  let text = '';
  let count = 5;
  do {
    text += 'Count: ' + count + '<br>';
    count--;
  } while (count > 0);
  output.innerHTML = text;
}