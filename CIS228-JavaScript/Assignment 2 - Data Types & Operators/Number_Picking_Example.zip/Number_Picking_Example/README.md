# Number Guessing Game - JavaScript Logic Sequence

## Overview
This game demonstrates basic JavaScript control flow concepts for an Intro to JavaScript course. The game generates a random number between 1-100 and prompts the user to guess it.

## Logic Flow

1. **Initialization** (`index.html:69`)
   - Generate random target number: `Math.floor(Math.random() * 100) + 1`
   - Initialize `guessCount = 0`
   - Cache DOM elements: `messageDiv`, `guessCountSpan`, `guessBtn`, `guessInput`

2. **Event Setup** (`index.html:76`)
   - Add click event listener to the "Submit Guess" button

3. **Per-Guess Processing** (on button click):
   a. Parse user input as integer: `parseInt(guessInput.value)`
   b. Increment `guessCount` and update display
   c. **Validate input**: If NaN or outside 1-100 range, show error message and exit
   d. **Compare guess to target**:
      - If `guess > targetNumber`: Display "Too high! Try again." (red background)
      - If `guess < targetNumber`: Display "Too low! Try again." (green background)
      - If `guess === targetNumber`: 
        - Display "Congratulations! You guessed the number in X guesses!"
        - Turn message green with centered text
        - Disable the guess button
   e. Clear input field and focus back on it

## Key JavaScript Concepts Demonstrated

- **Random number generation**: `Math.random()` combined with `Math.floor()`
- **Comparison operators**: `>`, `<`, `===`
- **Conditional logic**: `if / else if / else` chain
- **DOM manipulation**: `textContent`, `className`, `disabled`
- **Event handling**: `addEventListener('click', ...)`
- **Variable tracking**: Counter variable (`guessCount`) persistence

## Student Takeaways
- How to generate random numbers within a range
- Structuring multi-branch conditional logic
- Updating the webpage dynamically without refresh
- Tracking state across multiple user interactions